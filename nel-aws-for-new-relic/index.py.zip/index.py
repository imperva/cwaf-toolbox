import json
import boto3
import os
from botocore.exceptions import ClientError
def lambda_handler(event, context):
    if event["httpMethod"] == "POST":
        enrichment = {}
        for k, v in event["queryStringParameters"].items():
            enrichment[k] = v
        body = json.loads(event["body"])

        records = []
        for record in body:
            record["enrichment"] = enrichment
            msg_bytes = json.dumps(record).encode('utf-8')
            records.append({"Data": msg_bytes,
                            'PartitionKey': event["queryStringParameters"]["account_id"]})

        try:
            client = boto3.client('kinesis')
            response = client.put_records(
                Records=records,
                StreamName=os.environ['StreamName']
            )

            if "FailedRecordCount" in response:
                return {"statusCode": 201,
                        "headers": {
                            "content-type": "application/json",
                            "strict-transport-security": "max-age=300; includeSubDomains; preload",
                            "content-security-policy": "default-src 'none'"
                        },
                        "body": "ok"
                        }

        except ClientError as e:
            return {"statusCode": 500,
                    "headers": {
                        "content-type": "application/json",
                        "strict-transport-security": "max-age=300; includeSubDomains; preload",
                        "content-security-policy": "default-src 'none'"
                    },
                    "body": e.response['Error']['Message']
                    }
    else:
        return {"statusCode": 500,
                "headers": {
                    "content-type": "application/json",
                    "strict-transport-security": "max-age=300; includeSubDomains; preload",
                    "content-security-policy": "default-src 'none'"
                }
                }
